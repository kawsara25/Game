#pragma once
#include <string>
using namespace std;

class EventCard {
public:
	EventCard();
	//getters
	string getEventName(int id);
	//action
	void doEvent(int id);

private:
	string eventNames[5];
	int eventId;
};