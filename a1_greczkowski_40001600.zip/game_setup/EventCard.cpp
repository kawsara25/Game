#include "EventCard.h"
using namespace std;

EventCard::EventCard() {
	eventNames[0] = "Forecast";
	eventNames[1] = "Government Grant";
	eventNames[2] = "Airlift";
	eventNames[3] = "Resilient Population";
	eventNames[4] = "One Quiet Night";
};

void EventCard::doEvent(int id) {
	//TODO: add the actions in 
	switch (eventId) {
	case 0:
		break;
	case 1:
		break;
	case 2:
		break;
	case 3:
		break;
	case 4:
		break;
	}
}

string EventCard::getEventName(int id) {
	return eventNames[id];
}

