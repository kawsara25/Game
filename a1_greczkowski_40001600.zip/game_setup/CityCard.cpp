#include "CityCard.h"
using namespace std;

//constructor
CityCard::CityCard() {}

//getters
double CityCard::getPopulation() {
	return population;
}
string CityCard::getCityName() {
	return cityName;
}
string CityCard::getColor() {
	return color;
}