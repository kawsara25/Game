#pragma once
#include <string>
#include <stdexcept>
#include "Player.h"
using namespace std;


	Player::Player() {
		throw invalid_argument("Player must receive string:name");
	}
	
	Player::Player(string pName) {
		//for now, assume 'Player 1'
		playerNum = 1;
		playerName = pName;
		assignPawn();
		assignRole();
	}

	string Player::getPawnColor() {
		return pawnColor;
	}

	int Player::getRoleNum() {
		return role;
	}

	void Player::assignPawn() {
		Pawn pawn(playerNum);
		pawnColor = pawn.getColor();
	}
	void Player::assignRole() {
		role = rand() % 8;
	}
