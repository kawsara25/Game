#pragma once
#include <string>
using namespace std;

class RoleCard {
public:
	//constructor
	RoleCard();

	//role getter
	string getRole(int index);

	//return a description of special action based on the index of the role in the roles array
	string getSpecialAction(int index);
private:
	string roles[7] = { "Contingency Planner", "Dispatcher", "Medic", "Operations Expert", "Quarantine Specialist", "Researcher", "Scientist" };
};