#include "Player.h"
#include "ReferenceCard.h"
#include "RoleCard.h"
#include <iostream>
using namespace std;

/*
	Author: Colin Greczkowski 
	ID: 40001600
	Purpose of program: Driver program that will instantiate a player
		with all of the appropriate possessions for a game of Pandemic.
*/

void main() {
	//instantiate player
	string pName;

	cout << "What is your name?";
	cin >> pName;
	Player p1(pName);
	cout << "Hello " << pName << ", you are the " << p1.getPawnColor() << " pawn.\n";
	//reference card to read possible actions
	ReferenceCard refCard;
	refCard.readReferenceCard();
	//assign random role card and read its description
	RoleCard roleCard;
	cout << "You have been assigned role " << roleCard.getRole(p1.getRoleNum()) << "\n\n";
	cout << roleCard.getSpecialAction(p1.getRoleNum());
	system("pause");
}
