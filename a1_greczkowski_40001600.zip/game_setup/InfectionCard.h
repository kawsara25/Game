#pragma once
#include <string>
using namespace std;

class InfectionCard {
public:
	//constructor
	InfectionCard();
	//getters 
	string getColor();
	string getCityName();

	//setters
	void setColor(string color);
	void setCityName(string cityName);

	//action
	void initialInfect();
private:
	string color;
	string cityName;
};