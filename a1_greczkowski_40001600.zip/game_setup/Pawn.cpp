#pragma once
#include <string>
#include <stdexcept>
#include "Pawn.h"
using namespace std;


	//constructor receives a player number (1-4)
	Pawn::Pawn(int playerNum) {
		if (playerNum < 1 || playerNum > 4) {
			throw invalid_argument("Player number must be between 1 and 4.");
		}
		//set pawn color
		switch (playerNum) {
		case 1:
			setColor("red");
			break;
		case 2:
			setColor("blue");
			break;
		case 3:
			setColor("green");
			break;
		case 4:
			setColor("yellow");
			break;
		}
		//set pawn position to default position
		setPosition(0);
	}

	Pawn::Pawn() {
		throw invalid_argument("Pawn must be initialized with int playerNum (1-4)");
	}

	string Pawn::getColor() {
		return color;
	}

	int Pawn::getPosition() {
		return position;
	}

	void Pawn::setPosition(int pos) {
		position = pos;
	}

	void Pawn::setColor(string theColor) {
		color = theColor;
	}

