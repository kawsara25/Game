#pragma once
#include <string>
#include <stdexcept>
using namespace std;

class Pawn {
public:	
	//constructor receives a player number (1-4)
	Pawn(int playerNum);
	Pawn();
	string getColor();
	int getPosition();
	void setPosition(int pos);

private:
	string color;	//color of pawn (distinct)
	int position;	//the square the pawn is currently on (default: 0)

	void setColor(string theColor);
};
