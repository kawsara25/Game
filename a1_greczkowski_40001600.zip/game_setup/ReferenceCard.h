#pragma once
#include <string>
#include <iostream>
using namespace std;

class ReferenceCard {
public:
	//arrays to hold instructions of front and back side of card
	string sideA[5];
	string sideB[5];

	ReferenceCard();

	//pretty print the contents of a reference card
	void readReferenceCard();
};