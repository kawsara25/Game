#include "RoleCard.h"
#include <string>
using namespace std;

RoleCard::RoleCard() {};

//return the role
string RoleCard::getRole(int index) {
	return roles[index];
}

//return a description of special action based on the index of the role in the roles array
string RoleCard::getSpecialAction(int index) {
	string desc = "";
	switch (index) {
	case 0:
		desc = "The Contingency Planner may, as an action, take an Event card from anywhere in the Player Discard Pile and place it on his Role card. Only 1 Event card can be on his role card at a time. It does not count against his hand limit. When the Contingency Planner plays the Event card on his role card, remove this Event card from the game (instead of discarding it).";
		break;
	case 1:
		desc = "The Dispatcher may, as an action, either: move any pawn, if its owner agrees, to any city containing another pawn, or move another player�s pawn, if its owner agrees, as if it were his own.";
		break;
	case 2:
		desc = "The Medic removes all cubes, not 1, of the same color when doing the Treat Disease action. If a disease has been cured, he automatically removes all cubes of that color from a city, simply by entering it or being there. This does not take an action.";
		break;
	case 3:
		desc = "The Operations Expert may, as an action, either: build a research station in his current city without discarding (or using) a City card, or once per turn, move from a research station to any city by discarding any City card.";
		break;
	case 4:
		desc = "The Quarantine Specialist prevents both outbreaks and the placement of disease cubes in the city she is in and all cities connected to that city. She does not affect cubes placed during setup.";
		break;
	case 5:
		desc = "As an action, the Researcher may give any City card from her hand to another player in the same city as her, without this card having to match her city. The transfer must be from her hand to the other player�s hand, but it can occur on either player�s turn.";
		break;
	case 6:
		desc = "The Scientist needs only 4 (not 5) City cards of the same disease color to Discover a Cure for that disease.";
		break;
	}
	desc += "\n";
	return desc;
}
