#pragma once
#include <string>
using namespace std;

class CityCard {
public:
	//constructor
	CityCard();

	//getters
	double getPopulation();
	string getCityName();
	string getColor();
private:
	string cityName;
	string color;
	double population;
};