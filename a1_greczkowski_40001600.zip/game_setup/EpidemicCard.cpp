#include "EpidemicCard.h"
#include <string>
#include <iostream>
using namespace std;

//constructor
EpidemicCard::EpidemicCard(){
	epidemicActions[0] = "Increase: Move the infection rate marker forward 1 space on the Infection Rate Track.";
	epidemicActions[1] = "Draw the bottom card from the Infection Deck. Unless its disease color has been eradicated, put 3 disease cubes of that color on the named city. If the city already has cubes of this color, do not add 3 cubes to it. Instead, add just enough cubes so that it has 3 cubes of this color and then an outbreak of this disease occurs in the city. Discard this card to the Infection Discard Pile";
	epidemicActions[2] = "Reshuffle just the cards in the Infection Discard Pile and place them on top of the Infection Deck.";
}

void EpidemicCard::readEpidemicCard() {
	string theEpidemic = "---------------------------------------\n";
	for (int i = 0; i <= 2; i++) {
		theEpidemic += epidemicActions[i] + "\n\n";
	}	
	cout << theEpidemic;
}


void EpidemicCard::doEpidemic() {
	//increase infection rate by 1
	//draw new Infection Card, put 3 disease cubes of color InfectionCard->color on the InfectionCard->city
	//randomize infection discard pile, push to top of infection deck 
}