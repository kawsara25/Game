#pragma once
#include <string>
#include <stdexcept>
#include "Pawn.h"
using namespace std;

class Player {
public:
	Player();
	Player(string pName);

	string getPawnColor();
	int getRoleNum();

private:
	int playerNum;
	string playerName;
	string pawnColor;
	int role;

	void assignPawn();
	void assignRole();
};