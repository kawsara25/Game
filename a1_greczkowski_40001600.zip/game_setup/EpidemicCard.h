#pragma once
#include <string>
using namespace std;

class EpidemicCard {
public:
	EpidemicCard();

	void readEpidemicCard();
	void doEpidemic();
private:
	string epidemicActions[3];
};